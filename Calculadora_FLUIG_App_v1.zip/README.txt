# Calculadora FLUIG — primeira versão

Aplicativo web responsivo baseado na planilha CALCULADORA FLUIG.xlsx.

## Como usar
1. Abra `index.html` no navegador para testar.
2. Para instalar como aplicativo/PWA no celular ou PC, hospede a pasta em um servidor HTTPS.
3. A lógica atual reproduz as fórmulas encontradas na planilha.

## Arquivos
- index.html — aplicativo
- manifest.json — configuração de instalação
- sw.js — funcionamento offline básico
